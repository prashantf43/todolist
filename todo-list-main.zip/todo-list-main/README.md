# todo-list
 Simple todo list web app to save and manage todos, and save them to the local storage The web app has a beatifull UI design that is make it dun adding todos 
